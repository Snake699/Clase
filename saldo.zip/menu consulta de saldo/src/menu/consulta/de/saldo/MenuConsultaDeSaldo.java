/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menu.consulta.de.saldo;
import java.util.Scanner;
/**
 *
 * @author LAB-A2
 */
public class MenuConsultaDeSaldo {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String numerodecelular = "88006943";
        double saldoLPS = 100;
        double Datos = 0;
        double MSJ = 500;
        double Prestamo = 0;    
        double DarSaldo = 0;
        double monto = 0;
        int resp = 0;
   
        while(resp != -1){
            System.out.println("---- Bienvenido a Red de telefonia Celular ---- ");
            System.out.println(" 1. Consulta de saldo  "); 
            System.out.println(" 2. Consulta de Datos ");
            System.out.println(" 3. Solicitar un Prestamo");
            System.out.println("-1. Salir ");
            System.out.println(" Que desea realizar... ? ");
            resp = entrada.nextInt(); 
            switch(resp){
                case 1:
                    System.out.println("");
                    System.out.println("----------------------------------------");
                    System.out.println("Numero de Celuar "+numerodecelular);
                    System.out.println("Saldo en lempiras... "+saldoLPS);
                    System.out.println("Datos Disponibles...   ("+Datos+")");
                    System.out.println("----------------------------------------");
                    System.out.println("Saldo disponible...   "+saldoLPS);
                    System.out.println("----------------------------------------");
                    System.out.println("Credito pendiente....  "+Prestamo);
                    break;
                
                case 2: 
                    System.out.println("");
                    System.out.println("Debito de saldo #"+saldoLPS);
                    System.out.println("Saldo disponible...   "+saldoLPS);
                    System.out.println("Ingrese el numero a transferir saldo... ");
                    monto = entrada.nextDouble();
                    
                    if((saldoLPS-monto)> 25){
                        DarSaldo += monto;
                        saldoLPS = DarSaldo - Prestamo;
                        
                         }else{
                        System.err.println("No se puede transferir, saldo mayor al disponible");
                        resp = 0;
                    }
                 
                    
                 
                        
                        
                        
                    
}
            
